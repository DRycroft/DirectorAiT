-- Test migration to verify pipeline health
DO $$
BEGIN
  -- no-op
END;
$$;
